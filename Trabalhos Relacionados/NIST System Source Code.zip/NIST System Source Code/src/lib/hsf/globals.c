#include <stdio.h>

int _silent_, _verbose_, _time_;
FILE *_tfp_;
