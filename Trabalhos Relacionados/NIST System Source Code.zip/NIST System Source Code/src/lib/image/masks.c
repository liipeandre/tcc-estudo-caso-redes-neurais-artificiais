/************************************************************/
/*         File Name: Masks.c                               */
/*         Package:   External Global Mask Lists            */
/*         Date:      4/28/89                               */
/*                                                          */
/*         Contents:  Bit_Masks[]                           */
/************************************************************/

unsigned char bit_masks[8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
