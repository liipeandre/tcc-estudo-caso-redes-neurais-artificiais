extern unsigned char Bit_Count[256];
