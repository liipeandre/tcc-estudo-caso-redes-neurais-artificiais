
#define NO_ZM_ALLOC -100
#define    ZM_ALLOC  100

#define    MK_1_BIT  11
#define NO_MK_1_BIT -11
#define    MK_8_BIT  88
#define NO_MK_8_BIT -88

#define INPUT_IS_1 111
#define INPUT_IS_8 888
