typedef struct klparamstruct{
   int nbasis;
   float *basis;
   float *mu;
   float *sume;
} KL_PARAM;
