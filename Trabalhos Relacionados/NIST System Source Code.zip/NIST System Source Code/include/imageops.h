#define WD_SIZE		16.0
#define BYTE_SIZE	8.0

extern unsigned char *cut_image();
extern unsigned char *cut_exact_image();
extern unsigned char *imagedup();
