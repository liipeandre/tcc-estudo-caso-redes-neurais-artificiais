#define X_HIST 		0
#define Y_HIST		1

void compute_x_hist();
void compute_y_hist();
