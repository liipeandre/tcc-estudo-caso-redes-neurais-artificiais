#define MINPIXELS 100
#define MAXPIXELS 1750

#define ENTW 128
#define ENTH 128
#define BPI  300

#define MAX_BLOBS 750
