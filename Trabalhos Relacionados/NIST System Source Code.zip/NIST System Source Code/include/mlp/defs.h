#ifndef FALSE
#define FALSE ((char)0)
#define TRUE  ((char)1)
#endif
