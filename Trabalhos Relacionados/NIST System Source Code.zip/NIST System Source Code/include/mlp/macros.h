#ifndef _MACROS_INCLUDE
#define _MACROS_INCLUDE

#define min(x,y) ((x)<=(y)?(x):(y))
#define max(x,y) ((x)>=(y)?(x):(y))

#endif
