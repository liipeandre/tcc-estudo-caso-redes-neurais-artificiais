#define STPMIN 1.e-20
#define STPMAX 1.e+20
