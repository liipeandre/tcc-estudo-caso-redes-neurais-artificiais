#ifndef _RD_WORDS_INCLUDE
#define _RD_WORDS_INCLUDE

#define INT   ((char)0)
#define FLOAT ((char)1)

void rd_words();

#endif
