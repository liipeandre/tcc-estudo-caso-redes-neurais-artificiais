#ifndef _LIMS_INCLUDE
#define _LIMS_INCLUDE

#define MAXMED 100000
#define LONG_CLASSNAME_MAXSTRLEN 32

#endif
