char get_phr();

/* Names of get_phr()'s return values: */
#define WORD_PAIR      ((char)0)
#define NEWRUN         ((char)1)
#define ILLEGAL_PHRASE ((char)2)
#define FINISHED       ((char)3)
