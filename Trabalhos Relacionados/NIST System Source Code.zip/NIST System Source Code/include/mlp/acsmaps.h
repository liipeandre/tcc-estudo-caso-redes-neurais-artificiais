void (*acs_code_to_fn())();
char *acs_code_to_str();
char acs_str_to_code();
