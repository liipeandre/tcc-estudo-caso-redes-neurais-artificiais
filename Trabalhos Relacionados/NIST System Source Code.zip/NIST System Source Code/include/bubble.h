#define A_INCR 4
#define RADINC 0.017453293
