extern unsigned char mask_begin_1[];
extern unsigned char mask_begin_0[];
extern unsigned char mask_end_0[];
extern unsigned char mask_end_1[];
