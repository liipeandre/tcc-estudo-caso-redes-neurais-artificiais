extern unsigned char bit_masks[8];
