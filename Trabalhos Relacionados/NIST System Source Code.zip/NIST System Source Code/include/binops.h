#define BINARY_COPY	0
#define BINARY_OR	1
#define BINARY_AND	2
#define BINARY_XOR	3
#define BINARY_INVERT	4
#define BINARY_ZERO	5
#define BINARY_ONE	6
