#define LN10 2.302585093 	/* natural log of 10 			*/
#define LAMBDA 4 		/* do not add prototype contributions 	*/
				/* whose contribs are < 10-LAMBDA * the	*/
 				/* largest expontential term from the 	*/
 				/* closest prototype 			*/
#define BIG 1e30 		/* used for init of insertion sort 	*/
