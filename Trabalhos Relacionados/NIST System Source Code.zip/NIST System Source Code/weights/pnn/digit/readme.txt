Files h6_d.pat & h6_d_s.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat1 -vh d.set h6_d.evt h6_d h6_d.cl h6_d.ml
   % mis2pat1 -vh d.set h6_d_s.evt h6_d_s h6_d_s.cl h6_d_s.ml

