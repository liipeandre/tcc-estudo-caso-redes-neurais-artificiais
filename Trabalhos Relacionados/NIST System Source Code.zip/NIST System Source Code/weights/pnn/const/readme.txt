Files h46_ul.pat & h6_ul_s.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat1 -vh ul.set h46_ul.evt h46_ul h46_ul.cl h46_ul.ml
   % mis2pat1 -vh ul.set h6_ul_s.evt h6_ul_s h6_ul_s.cl h6_ul_s.ml
