File h46_l.pat removed from this release for internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat1 -vh l.set h46_l.evt h46_l h46_l.cl h46_l.ml

