Files h46_l.pat & h7_l.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat2 -vh l.set h46_l.evt h46_l.pat h46_l.cl h46_l.ml
   % mis2pat2 -vh l.set h46_l.evt h7_l.pat h7_l.cl h7_l.ml
