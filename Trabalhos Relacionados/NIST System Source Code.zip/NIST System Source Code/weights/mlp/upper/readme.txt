Files h46_u.pat & h7_u.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat2 -vh u.set h46_u.evt h46_u.pat h46_u.cl h46_u.ml
   % mis2pat2 -vh u.set h46_u.evt h7_u.pat h7_u.cl h7_u.ml
