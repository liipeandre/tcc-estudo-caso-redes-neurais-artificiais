Files h6_d.pat & h7_d.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat2 -vh d.set h6_d.evt h6_d.pat h6_d.cl h6_d.ml
   % mis2pat2 -vh d.set h6_d.evt h7_d.pat h7_d.cl h7_d.ml
