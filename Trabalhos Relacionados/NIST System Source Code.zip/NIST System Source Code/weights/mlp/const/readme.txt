Files h46_ul.pat & h7_ul.pat removed from this release for
internet distribution.

To regenerate this file:

   Training files from SD19 must first be linked or installed into
   ../../../train.  See "readme.txt" in $PROJDIR/train

   % mis2pat2 -vh ul.set h46_ul.evt h46_ul.pat h46_ul.cl h46_ul.ml
   % mis2pat2 -vh ul.set h46_ul.evt h7_ul.pat h7_ul.cl h7_ul.ml
